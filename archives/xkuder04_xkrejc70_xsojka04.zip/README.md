Extrakce csv souborů potřebných pro zodpovězení dotazů
---------
Tyto soubory byly příliš velké pro odevzdání a celkový archiv tedy překročil limit 10MB. V odevzdaném archivu je tedy nutné extrahované csv soubory vygenerovat. Postup je popsaný v přiložené dokumentaci.

Případně je možné stáhnou odevzdaný archiv s přiloženými csv soubory z gitlabu pro tento projekt: https://gitlab.com/xsojka04/upa .